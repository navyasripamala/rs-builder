function nextPage() {
  window.open("resumme.html","_self");

}
function nextPage1() {
  window.open("script.html","_self");

}
